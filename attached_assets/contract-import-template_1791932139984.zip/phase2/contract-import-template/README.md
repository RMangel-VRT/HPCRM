# Contract import template

Five CSVs, filled in for College Hills as a worked example (from the two signed MSI agreements). The `<...>` cells are placeholders for ids that come from the audit export (`customers.csv`, `old_contracts.csv`, `old_documents.csv`). Tests should use their own fixture ids.

| File | One row per |
|---|---|
| `contracts.csv` | season (term). `agreement_ref` groups the seasons of one contract; `renews_ref` links a season to the one it renews. |
| `payments.csv` | payment line per season, 12 month columns in dollars |
| `rates.csv` | rate that differs from the rate card (or a `custom_` rate) |
| `scope.csv` | service included, with an optional 12-month spread |
| `documents.csv` | existing document attached to a season |

What the example shows:
- **2025–26:** renewed, signed Jun 23, 2025. It ended Mar 31, 2026 because the 2026–27 agreement replaced it from Apr 1. Grounds maintenance only; chemical and snow were time and materials.
- **2026–27:** sent but not yet signed by the board, so it's flagged for review. It has two payment lines, Grounds maintenance $30,000/yr and Chemical $11,515/yr, for an annual price of $41,515. Snow is time and materials.
- **Rates:** only the ones that differ from the card, plus the per-contract labor rates.
- **Scope:** only for the current season.
